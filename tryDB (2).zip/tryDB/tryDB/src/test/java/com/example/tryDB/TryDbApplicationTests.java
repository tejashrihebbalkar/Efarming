package com.example.tryDB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TryDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
