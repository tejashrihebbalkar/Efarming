package com.example.tryDB.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.tryDB.entity.Buyer;
import com.example.tryDB.entity.Seller;
import com.example.tryDB.entity.User;
import com.example.tryDB.service.BuyerService;
import com.example.tryDB.service.SellerService;
import com.example.tryDB.service.UserService;

@Controller
public class DBController {

	@Autowired
	UserService userService;

	@Autowired
	BuyerService buyerService;

	@Autowired
	SellerService sellerService;

	@GetMapping("/")
	public String index() {
		return "index";
	}

	@RequestMapping("/login")
	public String login() {
		return "login";
	}

	@GetMapping("/choice")
	public String choice() {
		return "choice";
	}
	

	@GetMapping("/admin")
	public String admin() {
		return "adminHomePage";
	}


	@GetMapping("/signup-buyer")
	public String signUpBuyer(@ModelAttribute("buyer") Buyer buyer) {
		return "signup-buyer";
	}

	@GetMapping("/signup-seller")
	public String signUpSeller(@ModelAttribute("seller") Seller seller) {
		return "signup-seller";
	}

	@PostMapping("/buyer-login")
	public String registerationBuyer(@Valid @ModelAttribute("buyer") Buyer buyer, BindingResult result, ModelMap map) {
		Buyer findByUserName = buyerService.findByUserName(buyer.getUserName());
		Buyer findByEmailId = buyerService.findByEmailId(buyer.getEmailId());
		if (result.hasErrors() || findByUserName != null || findByEmailId != null) {
			if (findByUserName != null)
				map.addAttribute("username", "Username is already taken");
			if (findByEmailId != null)
				map.addAttribute("email", "EmailId is already registered");
			return "signup-buyer";
		}

		if (buyer.getPassword().equals(buyer.getConfirmPassword())) {
			
			User user = new User();
			user.setUserName(buyer.getUserName());
			user.setPassword(buyer.getPassword());
			user.setRole("buyer");
			user.setStatus("active");
			userService.create(user);
			buyer.setUser(user);
			buyerService.create(buyer);
			return "login";
		} else {
			String msg = "Password and Confirm password should be same";
			map.addAttribute("msg", msg);
			return "signup-buyer";
		}

	}

	@PostMapping("/seller-login")
	public String registerationSeller(@Valid @ModelAttribute("seller") Seller seller, BindingResult result,
			ModelMap map) {

		Seller findByUserName = sellerService.findByUserName(seller.getUserName());
		Seller findByEmailId = sellerService.findByEmailId(seller.getEmailId());
		if (result.hasErrors() || findByUserName != null || findByEmailId != null) {
			if (findByUserName != null)
				map.addAttribute("username", "Username is already taken");
			if (findByEmailId != null)
				map.addAttribute("email", "EmailId is already registered");
			return "signup-seller";
		}
		
		if (seller.getPassword().equals(seller.getConfirmPassword())) {
			
			User user = new User();
			user.setUserName(seller.getUserName());
			user.setPassword(seller.getPassword());
			user.setRole("seller");
			user.setStatus("active");
			userService.create(user);
			seller.setUser(user);
			sellerService.create(seller);
			return "login";
		} else {
			String msg = "Password and Confirm password should be same";
			map.addAttribute("msg", msg);
			return "signup-seller";
		}

	}

	@PostMapping("/login")
	public String loginSuccess(User user, ModelMap map) {
		User checkUser = userService.findByUsernameAndPassword(user.getUserName(), user.getPassword());
		if (checkUser != null) {
			if (checkUser.getStatus().equals("active")) {
				String UserRole = checkUser.getRole();
				switch (UserRole) {
				case "buyer":
					return "buyerHomePage";

				case "seller":
					return "sellerHomePage";

				case "admin":

					return "adminHomePage";

				}
			}
			return "";
		} else {
			map.addAttribute("error", "Invalid Username or Password");
			return "login";
		}

	}

	
	
	@GetMapping("/addAdmin")
	public void addingAdmin() {
		User user = new User("admin", "admin", "active", "admin");
		userService.create(user);
	}
	@GetMapping("/show-buyer")
	public String showAllUsers(HttpServletRequest request) {
		request.setAttribute("buyers", buyerService.showAllBuyers());
		request.setAttribute("mode", "ALL_BUYERS");
		return "buyerList";
	}
	
	@RequestMapping("/disble-buyer")
	public String disabledUser(@RequestParam String userName, HttpServletRequest request) {
		
		userService.disableUser(userName);
		request.setAttribute("buyers", buyerService.showAllBuyers());
		request.setAttribute("mode", "ALL_BUYERS");
		return "buyerList";
	}
	@GetMapping("/show-seller")
	public String showAllSellers(HttpServletRequest request) {
		request.setAttribute("sellers", sellerService.showAllSellers());
		request.setAttribute("mode", "ALL_SELLERS");
		return "sellerList";
	}
	
	@RequestMapping("/disble-seller")
	public String disabledSeller(@RequestParam String userName, HttpServletRequest request) {
		
		userService.disableUser(userName);
		request.setAttribute("sellers", sellerService.showAllSellers());
		request.setAttribute("mode", "ALL_SELLERS");
		return "sellerList";
	}
	
}
