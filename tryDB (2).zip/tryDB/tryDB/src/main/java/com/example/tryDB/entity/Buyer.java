package com.example.tryDB.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.UniqueElements;

import lombok.Data;

@Data
@Entity
public class Buyer {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String firstName;
	private String lastName;
	@Column(unique = true)
	private String userName;
	private String address;
	@Pattern(regexp = "[7-9]{1}[0-9]{9}", message = "Contact No. should be 10 digits and starting with digit 7/8/9")
	private String mobileNo;
	@Column(unique = true)
	@Email(message = "Provide in proper format")
	private String emailId;
	private String securityQns;
	@Transient
	private String password;
	@Transient
	private String confirmPassword;
	@OneToOne
	private User user;
}
