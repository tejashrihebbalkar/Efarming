package com.example.tryDB.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;

import lombok.Data;

@Data
@Entity
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@NotBlank(message = "Username cannot be blank")
	private String userName;
	@NotBlank(message = "Password cannot be blank")
	private String password;
	private String status;
	private String role;
	
	
	public User(String userName, String password, String status, String role) {
		super();
		this.userName = userName;
		this.password = password;
		this.status = status;
		this.role = role;
	}


	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
     