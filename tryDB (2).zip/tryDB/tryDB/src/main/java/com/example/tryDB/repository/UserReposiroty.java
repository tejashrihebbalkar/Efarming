package com.example.tryDB.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.tryDB.entity.Buyer;
import com.example.tryDB.entity.User;

@Repository
public interface UserReposiroty extends JpaRepository<User, Long> {
	
	@Query("select u from User u where u.userName = ?1 and u.password = ?2")
	public User findByUsernamePassword(String userName, String password);
   // @Query("select u from User u where u.userName = ?1")
	public User findByUserName(String userName);
    
    
}
