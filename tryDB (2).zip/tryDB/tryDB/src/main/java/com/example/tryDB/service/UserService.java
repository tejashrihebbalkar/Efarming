package com.example.tryDB.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.tryDB.entity.User;
import com.example.tryDB.repository.UserReposiroty;

@Service
public class UserService {

	@Autowired
	UserReposiroty userReposiroty;

	public User create(User user) {
		return userReposiroty.save(user);
	}

	public List<User> read() {
		return userReposiroty.findAll();
	}

	public User read(Long id) {
		return userReposiroty.findById(id).get();
	}

	public void update(User user) {
		userReposiroty.save(user);
	}

	public void delete(Long id) {
		userReposiroty.delete(read(id));
	}
	
	public User findByUsernameAndPassword(String username, String password) {
		return userReposiroty.findByUsernamePassword(username, password);
	}
	
	public void disableUser(String username) {
		User u=userReposiroty.findByUserName(username);
		
	    if(u.getStatus().equals("active")) {
	    	u.setStatus("disabled");
	    	
	    }
	    else
	    {
	    	u.setStatus("active");
	    	
	    }
	    
	    update(u);
	}
	
}
