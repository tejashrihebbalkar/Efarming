package com.example.tryDB.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.tryDB.entity.Buyer;
import com.example.tryDB.entity.Seller;
import com.example.tryDB.repository.SellerRepository;

@Service
public class SellerService {

	@Autowired
	SellerRepository sellerRepository;
	
	public Seller create(Seller seller) {
		return sellerRepository.save(seller);
	}

	public List<Seller> read() {
		return sellerRepository.findAll();
	}

	public Seller read(Long id) {
		return sellerRepository.findById(id).get();
	}

	public void update(Seller seller) {
		sellerRepository.save(seller);
	}

	public void delete(Long id) {
		sellerRepository.delete(read(id));
	}
	
	public Seller findByUserName(String userName) {
		return sellerRepository.findByUserName(userName);
	}
	
	public Seller findByEmailId(String emailId) {
		return sellerRepository.findByEmailId(emailId);
	}
	
	public List<Seller> showAllSellers(){
		List<Seller> sellers = new ArrayList<Seller>();
		for(Seller seller : sellerRepository.findAll()) {
			sellers.add(seller);
		}
		
		return sellers;
	}
}
