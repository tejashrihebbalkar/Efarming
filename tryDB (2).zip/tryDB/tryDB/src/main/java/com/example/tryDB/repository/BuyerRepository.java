package com.example.tryDB.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.tryDB.entity.Buyer;

@Repository
public interface BuyerRepository extends JpaRepository<Buyer, Long> {

	Buyer findByUserName(String userName);
	Buyer findByEmailId(String emailId);
	
}
