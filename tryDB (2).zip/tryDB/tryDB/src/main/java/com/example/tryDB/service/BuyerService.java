package com.example.tryDB.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.example.tryDB.entity.Buyer;
import com.example.tryDB.repository.BuyerRepository;

@Service
public class BuyerService {

	@Autowired
	BuyerRepository buyerRepository;
	
	public Buyer create(Buyer buyer) {
		return buyerRepository.save(buyer);
	}

	public List<Buyer> read() {
		return buyerRepository.findAll();
	}

	public Buyer read(Long id) {
		return buyerRepository.findById(id).get();
	}

	public void update(Buyer buyer) {
		buyerRepository.save(buyer);
	}

	public void delete(Long id) {
		buyerRepository.delete(read(id));
	}
	
	public Buyer findByUserName(String userName) {
		return buyerRepository.findByUserName(userName);
	}
	
	public Buyer findByEmailId(String emailId) {
		return buyerRepository.findByEmailId(emailId);
	}
	public List<Buyer> showAllBuyers(){
		List<Buyer> buyers = new ArrayList<Buyer>();
		for(Buyer buyer : buyerRepository.findAll()) {
			buyers.add(buyer);
		}
		
		return buyers;
	}
	
}
