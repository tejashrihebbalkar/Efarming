package com.example.tryDB.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Transient;
import javax.validation.constraints.Email;
import javax.validation.constraints.Pattern;

import lombok.Data;

@Data
@Entity
public class Seller {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String firstName;
    private String lastName;
    @Column(unique = true)
    private String userName;
    private String address;
    @Pattern(regexp = "[7-9]{1}[0-9]{9}", message = "Mobile number should be 10 digits and starting with digit 7/8/9")
    private String mobileNo;
    @Column(unique = true)
    @Email(message = "Provide in proper format")
    private String emailId;
    private String securityQns;
    private String shopName;
    private String shopDescription;
    @OneToOne
    private User user;
    @Transient
    private String password;
    @Transient
    private String confirmPassword;
}
